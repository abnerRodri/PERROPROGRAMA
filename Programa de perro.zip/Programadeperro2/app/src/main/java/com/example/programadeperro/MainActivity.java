package com.example.programadeperro;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edadInput;
    private Button btnDale;
    private TextView txtEdadCanina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edadInput = findViewById(R.id.Edad);
        btnDale = findViewById(R.id.Dale);
        txtEdadCanina = findViewById(R.id.EdadCanina);

        btnDale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularEdadCanina();
            }
        });
    }

    private void calcularEdadCanina() {
        String edadString = edadInput.getText().toString();
        if (!edadString.isEmpty()) {
            int edadHumana = Integer.parseInt(edadString);
            int edadCanina = edadHumana * 7; // Suponiendo que cada año humano equivale a 7 años caninos
            txtEdadCanina.setText("Tu edad canina es: " + edadCanina);
        } else {
            txtEdadCanina.setText("Por favor, ingresa tu edad.");
        }
    }
}
